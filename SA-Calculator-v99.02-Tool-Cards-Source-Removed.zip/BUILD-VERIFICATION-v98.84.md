# Build verification — v98.85

- `npm test`: 109/109 passed.
- `node --check assets/js/app.js`: passed.
- `node --check assets/js/localization.js`: passed.
- `node scripts/prepare-android-web.mjs`: passed; 13 required web assets verified.
- YAML parsing: 3/3 workflow copies valid and byte-identical.
- Release identity: `1.98.99-v98.85`, Android versionCode `1099105`, PWA manifest, HTML and runtime APP_VERSION synchronized.
- Service worker cache: `sa-calculator-v98-85-tool-cursor-unified-v9885`.
- Release test entry points: 19/19 exist; GST field and white-theme regression tests included in npm and CI verification.
- Root/`www` mirrored assets: 8/8 byte-identical.

Not performed: remote GitHub Actions execution, signed APK generation, physical Android device/touch/rotation testing, or device-specific performance measurement. Local checks do not prove zero bugs or lag on every device.

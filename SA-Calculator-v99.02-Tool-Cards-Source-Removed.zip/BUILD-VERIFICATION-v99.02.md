# v99.02 build verification

- Source baseline: v99.01 ZIP.
- App version: `1.99.16-v99.02`.
- Android version code: `1099140`.
- Card source cleanup: 558 CSS declarations removed across the two authored stylesheets; GST amount/rate form-card wrapper class removed from HTML.
- Regression suite: 145 passed, 0 failed.
- Web bundle prepared with 13 required assets.
- Root/www parity, unique HTML IDs, workflow YAML parsing and ZIP integrity verified.
- Physical Android / APK / remote CI execution: not performed.

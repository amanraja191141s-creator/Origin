# SA Calculator v99.02 — Tool card source removal

## Scope
- Removed legacy visual card declarations from the actual CSS source for tool wrapper families: form, input, result, data, field, row, launcher and favorite groups.
- Removed 533 legacy card/box declarations in the first source pass and 25 additional logical-spacing declarations in the follow-up pass across `assets/css/app.css` and `assets/css/tool-reference-ui.css`.
- Removed the GST form-card class from the amount and rate layout containers in `index.html`; retained neutral structural layout hooks (`gst-amount-layout`, `gst-rate-group`) so the controls remain grouped without card styling.
- Preserved calculator input nodes, GST amount/rate fields, mode and supply buttons, hidden native select synchronization, result rows, keypad, and settings/dialog surfaces.
- Updated app version, PWA manifest, service-worker cache namespace, Android version code and synchronized workflow mirrors.

## Verification
- Release regression suite: 145 passed, 0 failed.
- CSS source audit: tool wrapper card surface/fixed-box declarations absent for the audited wrapper selectors.
- HTML duplicate-ID check and source/generated bundle parity checked.
- Android workflow YAML mirrors parsed and compared for exact byte parity.
- ZIP integrity checked after packaging.

## Not performed
- No physical Android device test, APK installation, or remote GitHub Actions run was performed in this environment. A lag-free / bug-free guarantee is therefore not claimed.

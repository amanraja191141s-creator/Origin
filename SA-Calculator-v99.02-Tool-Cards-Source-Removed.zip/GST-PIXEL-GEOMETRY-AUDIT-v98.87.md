# GST Pixel Geometry Micro-Audit — v98.87

Reference screenshot: **709 × 1536 px**. Coordinates below are screenshot pixel coordinates (top-left origin), manually measured from the supplied image with approximately ±2–4 px edge tolerance. They are not Android dp values.

## Screen regions and element bounds

| Element | X | Y | Width | Height |
|---|---:|---:|---:|---:|
| Full screenshot canvas | 0 | 0 | 709 | 1536 |
| Status bar | 0 | 0 | 709 | 54 |
| Header/back/title region | 24 | 95 | 302 | 52 |
| Amount card | 25 | 182 | 659 | 178 |
| Amount icon tile | 53 | 221 | 98 | 98 |
| Amount label | 171 | 222 | 218 | 29 |
| Amount entry/caret line | 171 | 258 | 480 | 62 |
| With GST | 296 | 380 | 167 | 50 |
| Without GST | 483 | 380 | 202 | 50 |
| GST Rate card | 25 | 450 | 659 | 178 |
| Rate icon tile | 53 | 488 | 98 | 98 |
| GST Rate label | 171 | 488 | 170 | 30 |
| Add rate entry line | 171 | 540 | 275 | 43 |
| 5% quick-rate button | 459 | 513 | 89 | 50 |
| 18% quick-rate button | 558 | 513 | 98 | 50 |
| Same State | 249 | 647 | 193 | 49 |
| Different State | 462 | 647 | 223 | 49 |
| Keypad dock visible region | 24 | 808 | 661 | 598 |
| Keypad column 1 | 24 | 808 | 149 | 598 |
| Keypad column 2 | 193 | 808 | 154 | 598 |
| Keypad column 3 | 366 | 808 | 150 | 598 |
| Keypad column 4 | 536 | 808 | 149 | 598 |
| Ad banner | 24 | 1426 | 661 | 110 |

## Keypad row geometry

| Row | Y | Height | Columns |
|---|---:|---:|---|
| 1 (7, 8, 9, AC) | 808 | 135 | 4 equal columns |
| 2 (4, 5, 6, delete) | 961 | 136 | 4 equal columns |
| 3 (1, 2, 3, equals begins) | 1117 | 136 | 4 equal columns |
| 4 (00, 0, decimal, equals continues) | 1273 | 133 | 4 equal columns |
| Equals combined key | 1117 | 289 | column 4, rows 3–4 |

## Layout diagnosis

- Amount and rate cards share the same 659 px screenshot width and 178 px height.
- Icon tiles are 98 × 98 px; label/input content begins at x=171 px.
- The mode and place rows are intentionally right-aligned, not full-width two-column rows. Their exact widths are 167/202 px and 193/223 px respectively.
- The rate pills occupy their own right-side grid column and must not overlap the editable rate field.
- The keypad is docked at y=808 px. The advertisement begins at y=1426 px and is separate from the keypad.
- The screenshot shows the amount caret at the left edge before its placeholder. The release preserves one inline caret inside the `.input-text` span; it does not add a second sibling caret.

## v98.87 implementation

- Added a final authoritative GST layout layer using the screenshot's proportions and CSS-equivalent dimensions for an approximately 393 px layout viewport rendered at about 1.8×.
- Amount and rate fields stay left-aligned, borderless and in normal document flow.
- Mode and state rows use independent, right-aligned button widths.
- Rate quick actions occupy a separate grid column.
- Short and narrow viewport breakpoints reduce the geometry without allowing controls to collide.
- Result rows remain auto-height and visible; the GST content remains vertically scrollable with dock/safe-area bottom padding.
- Existing keypad and GST arithmetic/event handlers are unchanged.

## Measurement caveat

Screenshot pixel measurements are approximate because anti-aliased edges and shadow-free card boundaries do not always have a single exact pixel. CSS pixel sizes depend on Android WebView viewport and device scale factor; the CSS uses responsive values rather than treating screenshot pixels as universal dp.

# SA Calculator v98.95 — All-tool cards (430 × 64)

Mobile-first calculator application with standard/scientific calculation, history, favorites, themes, localization, and 19 calculator tools.

## Release identity
- App version: `1.99.09-v98.95`
- Android versionCode: `1099115`
- Service-worker cache: `sa-calculator-v98-95-all-tool-card-geometry-430x64-v9895`
- Android workflow: `.github/workflows/main.yml` (also supplied as `sa-calculator-v98.95-android.yml`)

## v98.95 change
Previously standardized calculator-tool cards were reduced from 114px to exactly 64px (50px shorter), retaining a 430px maximum width and fluid sizing on narrow screens. Dense card content uses contained vertical scrolling rather than being intentionally clipped. See `TOOL-CARD-GEOMETRY-AUDIT-v98.95.md`.

## Verify locally
```sh
npm run test:release
npm run build:web
```

## Android APK
The workflow installs Capacitor dependencies, builds and verifies the web bundle, runs release regression tests, syncs the Android project, applies native branding, builds a debug APK, checks its version identity, and uploads it as a GitHub Actions artifact. The source ZIP does not contain a prebuilt APK. Run the workflow in GitHub Actions to produce the APK.

## Validation boundary
See `BUILD-VERIFICATION-v98.95.md` for checks completed against this archive. Automated tests and source inspection do not prove zero lag, zero bugs, or identical touch/layout behavior on every physical Android device. Physical-device visual, touch, scroll, performance, and APK-install testing remain separate release checks.


## Latest release — v98.96

See `TOOL-CARD-CONTENT-GEOMETRY-AUDIT-v98.96.md`, `RELEASE-NOTES-v98.96.md`, and `BUILD-VERIFICATION-v98.96.md`. The shared card layer now constrains width only; each tool retains its content-first dimensions.

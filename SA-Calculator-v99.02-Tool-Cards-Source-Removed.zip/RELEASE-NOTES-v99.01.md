# SA Calculator v99.01 — Tool card CSS purge

- Removed tool-container card chrome declarations from source CSS instead of layering another override.
- Removed the v99.00 end-of-file cardless override block.
- Preserved actual input controls, select fields, buttons, focus indicators, modal/dialog surfaces, Settings panels, and calculator behavior.
- Renamed JavaScript result-panel variables and tool launcher item references to remove stale card terminology from tool flows.
- Kept required semantic grouping nodes and IDs so existing event wiring and accessibility relationships remain intact.

Release: `1.99.15-v99.01` · Android versionCode `1099130`

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const css = fs.readFileSync(path.join(root,'assets/css/tool-reference-ui.css'),'utf8');
const html = fs.readFileSync(path.join(root,'index.html'),'utf8');
const app = fs.readFileSync(path.join(root,'assets/js/app.js'),'utf8');

test('GST amount and rate use one child-owned placeholder, never a duplicate parent pseudo-element',()=>{
  assert.match(css, /#tax-orig\.input-val-box\[data-tool-field="true"\]::after[\s\S]*?#tax-rate\.input-val-box\[data-tool-field="true"\]::after\s*\{\s*content:none !important;\s*display:none !important;/);
  assert.match(css, /#tax-orig \.input-text\.is-empty::after[\s\S]*?#tax-rate \.input-text\.is-empty::after/);
  assert.match(css, /#tax-orig \.input-text:not\(\.is-empty\)::after[\s\S]*?#tax-rate \.input-text:not\(\.is-empty\)::after/);
});

test('GST value renderer synchronizes empty state on both field and child before paint',()=>{
  assert.match(app, /textSpan\.classList\.toggle\('is-empty', isEmpty\);\s*target\.classList\.toggle\('is-empty', isEmpty\);/);
  assert.match(app, /textSpan\.dataset\.placeholder\s*=\s*target\.dataset\.placeholder/);
});

test('GST fields keep their placeholder text nodes and tool-field semantics',()=>{
  for (const id of ['tax-orig','tax-rate']) {
    const re = new RegExp(`<div class="input-val-box[^>]*id="${id}"[\\s\\S]*?<span class="input-text is-empty" data-placeholder="[^"]+"`);
    assert.match(html,re);
  }
});

test('v98.98 release identity and cache namespace are synchronized',()=>{
  const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
  const sw=fs.readFileSync(path.join(root,'service-worker.js'),'utf8');
  assert.equal(pkg.version,'1.99.16-v99.02');
  assert.equal(pkg.androidVersionCode,1099140);
  assert.match(sw,/sa-calculator-v99-02-all-tool-card-style-removed-v9902/);
});

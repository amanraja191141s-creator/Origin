import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
test('GST rate card has a deterministic top label and lower input/preset row',()=>{
 const html=read('index.html'), css=read('assets/css/tool-reference-ui.css');
 assert.match(html,/<span class="gst-rate-label">GST Rate\(%\)<\/span>/);
 assert.match(html,/class="gst-rate-entry-row"[\s\S]*?data-placeholder="Add rate"[\s\S]*?data-gst-rate="5"[\s\S]*?data-gst-rate="18"/);
 assert.match(css,/\.gst-rate-group \.gst-rate-label[\s\S]*?inset:0 0 auto 0/);
 assert.match(css,/\.gst-rate-group \.gst-rate-entry-row[\s\S]*?inset:auto 0 0 0/);
});
test('GST placeholders are painted once by the field, never by child text spans',()=>{
 const css=read('assets/css/tool-reference-ui.css');
 assert.match(css,/#tax-orig \.input-text\.is-empty::after[\s\S]*?content:none !important/);
 assert.match(css,/#tax-rate \.input-text\.is-empty::after[\s\S]*?content:none !important/);
 assert.match(css,/#tax-orig\.is-empty::after[\s\S]*?content:attr\(data-placeholder\)/);
 assert.match(css,/#tax-rate\.is-empty::after[\s\S]*?content:attr\(data-placeholder\)/);
});
test('Different State row visibility is applied before validity checks',()=>{
 const js=read('assets/js/app.js');
 const start=js.indexOf('function calcSalesTax()'), end=js.indexOf('// 7. BODY METRICS',start);
 const fn=js.slice(start,end);
 assert.ok(fn.indexOf("toggleAttribute('hidden', !same)") < fn.indexOf('if (!valid)'));
 assert.ok(fn.indexOf("toggleAttribute('hidden', same)") < fn.indexOf('if (!valid)'));
 assert.match(fn,/tax-igst-row.*setAttribute\('aria-hidden', String\(same\)\)/);
});
test('Manual rate entry synchronizes 5% and 18% preset state',()=>{
 const js=read('assets/js/app.js');
 assert.match(js,/normalizedRate = String\(val\)/);
 assert.match(js,/item\.dataset\.gstRate === normalizedRate/);
});
test('Release identity is v98.92',()=>{
 const pkg=JSON.parse(read('package.json'));
 assert.equal(pkg.version,'1.99.16-v99.02'); assert.equal(pkg.androidVersionCode,1099140);
});

import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read=p=>fs.readFileSync(p,'utf8');
test('v99.02 GST markup no longer uses tool card wrapper classes',()=>{
 const html=read('index.html');
 const gst=html.slice(html.indexOf('id="screen-salestax"'),html.indexOf('id="screen-agecalc"'));
 assert.ok(gst.includes('class="gst-amount-layout"'));
 assert.ok(gst.includes('class="gst-rate-group"'));
 assert.ok(!gst.includes('tool-form-content'));
});
test('v99.02 shared tool containers have no authored card surface or fixed box geometry',()=>{
 const postcss=require('/opt/nvm/versions/node/v22.16.0/lib/node_modules/postcss');
 const forbidden=/^(?:background(?:-color|-image)?|border(?:-color|-style|-width|-radius)?|box-shadow|padding(?:-.+)?|margin(?:-.+)?|min-height|max-height|height|overflow(?:-x|-y)?)$/i;
 for(const file of ['assets/css/tool-reference-ui.css','assets/css/app.css']) {
  const ast=postcss.parse(read(file));
  ast.walkRules(rule=>{
   const selectors=rule.selectors||[rule.selector];
   const targets=selectors.filter(sel=>['tool-form-content','tool-input-group','tool-result-content','tool-data-group','tool-field-group','tool-field-row','tool-data-row','tool-hero-content','gst-rate-group','tool-launch-item','favorite-tool-item'].some(c=>new RegExp('\\.'+c+'(?:\\[[^\\]]+\\])?(?::[\\w-]+(?:\\([^)]*\\))?)*$').test(sel.trim())));
   if(!targets.length)return;
   rule.walkDecls(d=>assert.equal(forbidden.test(d.prop),false,`${file}: ${targets.join(',')} retains ${d.prop}`));
  });
 }
});
test('v99.02 release identity and generated web bundle are synchronized',()=>{
 const p=JSON.parse(read('package.json'));
 assert.equal(p.version,'1.99.16-v99.02'); assert.equal(p.androidVersionCode,1099140);
 assert.ok(read('index.html').includes(p.version)); assert.ok(read('assets/js/app.js').includes(`const APP_VERSION = '${p.version}'`));
 assert.equal(read('assets/css/app.css'),read('www/assets/css/app.css'));
 assert.equal(read('assets/css/tool-reference-ui.css'),read('www/assets/css/tool-reference-ui.css'));
});
